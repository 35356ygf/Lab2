package com.example.lab2;

public class tbl_user {
    private int user_id;
    private String u_name;
    private String u_email;
    private String u_password;

    public tbl_user(int user_id, String u_name, String u_email, String u_password) {
        this.user_id = user_id;
        this.u_name = u_name;
        this.u_email = u_email;
        this.u_password = u_password;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getU_name() {
        return u_name;
    }

    public void setU_name(String u_name) {
        this.u_name = u_name;
    }

    public String getU_email() {
        return u_email;
    }

    public void setU_email(String u_email) {
        this.u_email = u_email;
    }

    public String getU_password() {
        return u_password;
    }

    public void setU_password(String u_password) {
        this.u_password = u_password;
    }
}
