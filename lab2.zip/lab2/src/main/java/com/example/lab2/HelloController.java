package com.example.lab2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;
import java.sql.*;

public class HelloController implements Initializable {
    public TableView<tbl_user> userTable;
    public TableColumn<tbl_user, Integer> user_id;
    public TableColumn<tbl_user, String> u_name;
    public TableColumn<tbl_user, String> u_email;
    public TableColumn<tbl_user, String> u_password;
    public TextField uid;
    public TextField uname;
    public TextField uemail;
    public TextField upassword;
    @FXML
    private Label welcomeText;

    ObservableList<tbl_user> list = FXCollections.observableArrayList();

    @FXML
    protected void onHelloButtonClick() {
        fetchdata();
    }

    private void fetchdata() {
        list.clear();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM tbl_user";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                int user_id = resultSet.getInt("user_id");
                String u_name = resultSet.getString("u_name");
                String u_email = resultSet.getString("u_email");
                String u_password = resultSet.getString("u_password");
                list.add(new tbl_user(user_id, u_name, u_email, u_password));
            }
            userTable.setItems(list);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        user_id.setCellValueFactory(new PropertyValueFactory<>("user_id"));
        u_name.setCellValueFactory(new PropertyValueFactory<>("u_name"));
        u_email.setCellValueFactory(new PropertyValueFactory<>("u_email"));
        u_password.setCellValueFactory(new PropertyValueFactory<>("u_password"));
        userTable.setItems(list);
    }

    public void InsertData(ActionEvent actionEvent) {
        String u_name = uname.getText();
        String u_email = uemail.getText();
        String u_password = upassword.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "INSERT INTO tbl_user (u_name, u_email, u_password) VALUES ('" + u_name + "','" + u_email + "','" + u_password + "')";
            Statement statement = connection.createStatement();
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void UpdateData(ActionEvent actionEvent) {
        String user_id = uid.getText();
        String u_name = uname.getText();
        String u_email = uemail.getText();
        String u_password = upassword.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE tbl_user SET u_name = '" + u_name + "', u_email = '" + u_email + "', u_password = '" + u_password + "' WHERE user_id = '" + user_id + "'";
            Statement statement = connection.createStatement();
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DeleteData(ActionEvent actionEvent) {
        String user_id = uid.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM tbl_user WHERE user_id = '" + user_id + "'";
            Statement statement = connection.createStatement();
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void LoadData(ActionEvent actionEvent) {
        String user_id = uid.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab2";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM tbl_user WHERE user_id = '" + user_id + "'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                String u_name = resultSet.getString("u_name");
                String u_email = resultSet.getString("u_email");
                String u_password = resultSet.getString("u_password");

                uname.setText(u_name);
                uemail.setText(u_email);
                upassword.setText(u_password);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
